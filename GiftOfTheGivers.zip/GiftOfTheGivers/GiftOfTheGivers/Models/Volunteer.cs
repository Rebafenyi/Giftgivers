﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers.Models
{
    public class Volunteer
    {
        public int Id { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        public string TaskAssigned { get; set; }

        public DateTime TaskDate { get; set; }
    }
}
