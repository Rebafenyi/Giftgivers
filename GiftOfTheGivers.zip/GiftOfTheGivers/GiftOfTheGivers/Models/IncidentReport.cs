﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers.Models
{
    public class IncidentReport
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        [Display(Name = "Incident Date")]
        public DateTime IncidentDate { get; set; }

        [Required]
        public string Location { get; set; }
    }
}
