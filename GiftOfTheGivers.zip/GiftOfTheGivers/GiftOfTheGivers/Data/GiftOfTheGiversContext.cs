﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GiftOfTheGivers.Models;

namespace GiftOfTheGivers.Data
{
    public class GiftOfTheGiversContext : DbContext
    {
        public GiftOfTheGiversContext (DbContextOptions<GiftOfTheGiversContext> options)
            : base(options)
        {
        }

        public DbSet<GiftOfTheGivers.Models.Donation> Donation { get; set; } = default!;
        public DbSet<GiftOfTheGivers.Models.IncidentReport> IncidentReport { get; set; } = default!;
        public DbSet<GiftOfTheGivers.Models.Volunteer> Volunteer { get; set; } = default!;
    }
}
